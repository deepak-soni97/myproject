import { Component } from "@angular/core";
import { IVideoConfig } from "ngx-video-list-player";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
    config: IVideoConfig = {
        isVideoLoader: true,
        isAutoPlay: false,
        isFirstVideoAutoPlay: false,
        subtitleOffText: "",
        subtitleText: "",
        volumeCookieName: "NgxVideoListPlayerVolume",
        videoIndexCookieName: "NgxVideoListPlayerIndex",
        sources: [{
            src: "https://qa-edupedia.s3.eu-west-1.amazonaws.com/TopicFiles/637786387364122269_Reset%20Password.webm?X-Amz-Expires=14400&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAQCQWSZETG524KYXR/20220209/eu-west-1/s3/aws4_request&X-Amz-Date=20220209T060435Z&X-Amz-SignedHeaders=host&X-Amz-Signature=594104c2c100f159a1d89ecc6556b183129208d9797028ac1d30d3909f219a52",
            videoName: "",
            artist: "",
            // subtitles: [
            //     {
            //         name: "English",
            //         src: "./assets/subtitles/en.vtt",
            //         default: false
            //     },
            //     {
            //         name: "Deutsche",
            //         src: "./assets/subtitles/de.vtt",
            //         default: false
            //     }
            // ]
        },
        // {
        //     src: "o_1aF54DO60",
        //     isYoutubeVideo: true,
        //     videoName: "(Youtube) Young and Beautiful",
        //     artist: "Lana Del Rey"
        // },
        // {
        //     src: "https://drive.google.com/uc?export=download&id=1pef_q-vfGKA4Z5XnrxscC1L8KHAngth9",
        //     videoName: "Martin Garrix feat. Bonn - High On Life",
        //     artist: "Martin Garrix"
        // }
    ]          
    };

    onTimeUpdate() {
        console.log("Event: onTimeUpdate");
    }

    onCanPlay() {
        console.log("Event: onCanPlay")
    }

    onLoadedMetadata() {
        console.log("Event: onLoadedMetadata")
    }

    constructor() {       

    }
}
